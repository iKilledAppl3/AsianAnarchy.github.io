Hello Themer! Welcome to CustomClock!

As you can see, there's png files for controlling various parts such as the hands and the dots.

There's also ClockIconBackgroundSquare@2x~iphone.png, ClockIconBackgroundSquare~ipad.png, and ClockIconBackgroundSquare@2x~ipad.png for customizing the clock background. (Not included in the example theme as CoolStar is a developer, not a designer :P)

Anyways, feel free to play around it. I'd love to see what awesome clock themes you come up with!